package com.Bookclub.BookClub.service.dao;

import com.Bookclub.BookClub.model.Book;
import com.Bookclub.BookClub.service.GenericDao;

public interface BookDao extends GenericDao<Book,String> {
}
