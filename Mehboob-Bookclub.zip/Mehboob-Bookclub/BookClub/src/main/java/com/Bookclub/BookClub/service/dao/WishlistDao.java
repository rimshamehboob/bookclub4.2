package com.Bookclub.BookClub.service.dao;

import com.Bookclub.BookClub.model.WishlistItem;
import com.Bookclub.BookClub.service.GenericDao;

public interface WishlistDao extends GenericDao<WishlistItem,String> {
}
